import React from 'react'
import './Footer.css'
// Bootstrap CSS
import "bootstrap/dist/css/bootstrap.min.css";
// Bootstrap Bundle JS
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTwitter,faInstagram,faGoogle,faYoutube } from '@fortawesome/free-brands-svg-icons';
import "bootstrap/dist/js/bootstrap.bundle.min";
function Footer() {
  return (
  <footer
        className="text-center text-lg-start text-black"
          >
    
      
            <div className="p-3">
              © 2020 Copyright: UTAS Students
            </div>
 
            
            <ul>
            <li><FontAwesomeIcon icon={faTwitter} /></li>
            <li><FontAwesomeIcon icon={faInstagram} /></li>
            <li><FontAwesomeIcon icon={faGoogle} /></li>
            <li><FontAwesomeIcon icon={faYoutube} /></li>
      </ul>
        </footer>
  )
}

export default Footer
