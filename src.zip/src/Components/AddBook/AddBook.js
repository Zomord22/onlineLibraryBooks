import React, { useState } from 'react';
import Axios from 'axios';

const AddBook = () => {
  const [id, setId] = useState(0);
  const [name, setName] = useState('');
  const [author, setAuthor] = useState('');
  const [publishYear, setPublishYear] = useState('');
  const [type, setType] = useState('');
  const [image, setImage] = useState('');


  
  const addBook = async () => {
    try {
      if (!id || !name || !author || !publishYear || !type || !image) {
        alert("All fields are required.");
      } else {
        const response = await Axios.post("http://localhost:3001/addBook", {
          id:id, 
          name: name,
          author: author,
          publishYear: publishYear,
          type: type,
          image:image
        });
        // Handle successful response
        console.log(response.data.msg);
    
      }
    } catch (err) {
      // Handle errors
      console.error(err);
    }
  };


  return (
    <div className="container">
     
      
     <div className="form-group">
          <label>Your Book ID:</label>
          <input
            type="text"
            name="id"
            value={id}
            onChange={(e) => {
              setId(e.target.value);
            }}
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
            }}
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label>Author:</label>
          <input
            type="text"
            name="author"
            value={author}
            onChange={(e) => {
              setAuthor(e.target.value);
            }}
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label>Publish Year:</label>
          <input
            type="text"
            name="publishYear"
            value={publishYear}
            onChange={(e) => {
              setPublishYear(e.target.value);
            }}
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label>Type:</label>
          <input
            type="text"
            name="type"
            value={type}
            onChange={(e) => {
              setType(e.target.value);
            }}
            className="form-control"
          />
        </div>
      <div className="form-group">
          <label>ImageURL:</label>
          <input
            type="text"
            name="imageURL"
            value={image}
            onChange={(e) => {
              setImage(e.target.value);
            }}
            className="form-control"
          />
        </div><br /><br />
        <button type="submit" className="btn btn-dark"  onClick={addBook}>Create Book</button>
    </div>
  );
};

export default AddBook;