import React, { useEffect, useState } from 'react';
import Axios from 'axios';
import './BookList.css'

function Showbooks() {
      
  const [books, setBooks] = useState([]);
  const [countRecords, setcountRecords] = useState(0);

    useEffect(() => {
        Axios.get("http://localhost:3001/manage")
          .then((response) => {
            setBooks(response.data.result);
            setcountRecords(response.data.count);
          })
          .catch((err) => {
            console.log(err);
          });
      }, []);
    
    return (
        <div className="menu">
          <h1 className="menuTitle">Library Book</h1>
          <div className="menuList">
            {books.map((book) => (
              <div className="menuItem">
                <div className='menuimage'><img src={book.image} alt={book.name} /></div>
                <div className='menuInfo'> 
                <h5> {book.name} </h5>
                <p> Author: {book.author}<br />
                  Publish Year: {book.publishYear}</p>
                <button className="btn btn-dark">Read Now !!</button></div>
              </div>
            ))}</div></div>
        
      );
}

export default Showbooks
