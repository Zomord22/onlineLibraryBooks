import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Axios from 'axios';
import './BookList.js'

const ListBook = () => {
  
  const [books, setBooks] = useState([]);
  const [countRecords, setcountRecords] = useState(0);

  const deleteBook = async (id) => {
    try {
      const confirmDelete = window.confirm("Do you really want to delete?");
      if (confirmDelete) {
        const response = await Axios.delete(
          `http://localhost:3001/delete/${id}`
        );
        setBooks(
          books.filter((val) => {
            return val._id != id;
          })
        );
    
        setcountRecords(response.data.count);
        console.log(countRecords)
        alert("Record deleted.");
      }
    } catch (err) {
      console.log("Error");
    }
  };

  useEffect(() => {
    Axios.get("http://localhost:3001/manage")
      .then((response) => {
        setBooks(response.data.result);
        setcountRecords(response.data.count);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  return (

<div className="menu">
<h1 className="menuTitle">Library Book</h1>
<div className="menuList">
  {books.map((book) => (
    <div className="menuItem">
      <div className='menuimage'><img src={book.image} alt={book.name} /></div>
      <div className='menuInfo'> 
      <h5> {book.name} </h5>
      <p> Author: {book.author}<br />
        Publish Year: {book.publishYear}</p>
        <button onClick={() => deleteBook(book._id)} className="btn btn-danger">Delete</button>
            <Link to={`/editBook/${book._id}`} className="btn btn-primary">Edit</Link>
    </div></div>
  ))}
    </div>
    </div>
  );
};
export default ListBook;