// Bootstrap CSS
import "bootstrap/dist/css/bootstrap.min.css";
// Bootstrap Bundle JS
import "bootstrap/dist/js/bootstrap.bundle.min";
import Axios from "axios";
import { useState, useEffect } from "react";
import './EditBook.css'
import { useParams } from "react-router-dom";

const EditBook = () => {
  const [name, setName] = useState('');
  const [author, setAuthor] = useState('');
  const [publishYear, setPublishYear] = useState('');
  const [type, setType] = useState('');
  const [image, setImage] = useState('');
  let id = useParams();
  const editBook = async (id) => {
    try {
      if ( !name || !author || !publishYear || !type || !image ) {
        alert("All fields are required.");
      } else {
        
        const response = await Axios.put(`http://localhost:3001/editBook/${id}`, {
          name: name,
          author: author,
          publishYear: publishYear,
          type: type,
          image:image
        });
        // Handle successful response
        console.log(response.data.msg);
    
      }
    } catch (err) {
      // Handle errors
      console.log(err);
    }
  };
  useEffect(() => {
    Axios.get(`http://localhost:3001/getbook/${id}`)
      .then((response) => {
        console.log(response);
        setName(response.data.result.name);
        setAuthor(response.data.result.author);
        setPublishYear(response.data.result.publishYear);
        setImage(response.data.result.image);
      })
      .catch((err) => {
        console.log(err);
      });
  }, [id]);
  
  return (
    <div className="container">

        <div className="form-group">
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
            }}
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label>Author:</label>
          <input
            type="text"
            name="author"
            value={author}
            onChange={(e) => {
              setAuthor(e.target.value);
            }}
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label>Publish Year:</label>
          <input
            type="text"
            name="publishYear"
            value={publishYear}
            onChange={(e) => {
              setPublishYear(e.target.value);
            }}
            className="form-control"
          />
        </div>
        <div className="form-group">
          <label>Type:</label>
          <input
            type="text"
            name="type"
            value={type}
            onChange={(e) => {
              setType(e.target.value);
            }}
            className="form-control"
          />
        </div>
      <div className="form-group">
          <label>ImageURL:</label>
          <input
            type="text"
            name="imageURL"
            value={image}
            onChange={(e) => {
              setImage(e.target.value);
            }}
            className="form-control"
          />
        </div><br /><br />
        <button type="submit" className="btn btn-dark"  onClick={editBook}>Update Book</button>
    </div>
  );
};

export default EditBook;