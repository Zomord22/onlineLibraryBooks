import React, {  useState  } from "react"
import axios from "axios"
import { useNavigate ,Link } from "react-router-dom"


function AddNewAdmin() {
    const history=useNavigate();
    const [email,setEmail]=useState('')
    const [password,setPassword]=useState('')
    const addNewAdmin = async () => {
        try{
            await axios.post("http://localhost:3001/addNewAdmin",{
                email,password
            })
            .then(res=>{
                if (res.data == "exist") {
                    alert("Admin already exists")
                }
                else if (res.data == "notexist") {
                    history("/Navbar", { state: { id: email } })
                        {<Link to='/Navbar' >Go To Home</Link>}
                }
            })
            .catch(e=>{
                alert("wrong details")
                console.log(e);
            })

        }
        catch(e){
            console.log(e);

        }

    }


    return (
<div className="form-structor">
	<div className="signup">
		<h2 className="form-title" id="signup">Add New Admin</h2>
		<div className="form-holder">
			<input type="text" onChange={(e) => { setEmail(e.target.value) }}   placeholder="Name" />
			<input type="email" className="input" placeholder="Email" />
			<input type="password" onChange={(e) => { setPassword(e.target.value) }} placeholder="Password" />
		</div>
		<button className="submit-btn" onClick={addNewAdmin}>New Admin</button>
	</div>
</div>
    )
}

export default AddNewAdmin;