import React, { useState } from "react"
import Axios from "axios"
import './Login.css'

function LoginAdmin() {

    const [email,setEmail]=useState('')
    const [password,setPassword]=useState(0)
    const loginAdmin = async () => {
        try {
          if (!email || !password ) {
            alert("All fields are required.");
          } else {
            const response = await Axios.post("http://localhost:3001/loginAdmin", {
                email: email,
                password:password
            });
            // Handle successful response
            console.log(response.data.msg);
        
          }
        } catch (err) {
          // Handle errors
          console.log(err);
        }
      };


    return (
        <div className="login">

            <h1>Login</h1>
<div className="Form">
            <label htmlFor="username">Username</label><br />
                <input type="text" onChange={(e) => { setEmail(e.target.value) }} placeholder="Username"  />
            <br />
            <label htmlFor="password">Password</label>  <br />  
            <input type="password" onChange={(e) => { setPassword(e.target.value) }} placeholder="Password" />
            <br /><br /><a href="Navbar"><button type="submit" className="btn btn-dark"  onClick={loginAdmin}>Login</button></a>

            <br />
</div>
        </div>
    )
}

export default LoginAdmin