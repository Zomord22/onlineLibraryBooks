import React from "react";
import "../styles/About.css";
function About() {
  return (
    <div className="about">
      <div className="aboutBottom">
        <h1> ABOUT US</h1>
        <p>
          An online library offers a vast collection of books in
          digital format, allowing individuals to access and read
          them conveniently using electronic devices such as
          computers, tablets, or e-readers.Online library books<br />
          offer a convenient, accessible,and versatile reading<br />
          experience, empowering individuals to explore a vast<br />
          world of literature without the constraints of physical<br />
          copies or geographic limitations.<br />
        </p>
      </div>
    </div>
  );
}

export default About;
