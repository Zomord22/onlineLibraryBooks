import React from "react";
import { Link } from "react-router-dom";
import BookImage from "../assets/books.jpg";
import "../styles/Home.css";


function Home() {
  return (
      <div className="home" style={{ backgroundImage: `url(${BookImage})` }}>
      <div className="headerContainer">
      <h2> 
      Our Online<br />
      Library Books<br />
      </h2>
        <p>
                You can Read books <br />
        as Reader. Also, you <br />
        can upload your books<br />
        As Author. All that <br />
        our website lets start !!<br />
        </p>
        <Link to="/manageBook">
          <button> Read Now !! </button>
        </Link>
      </div>
    </div>
  );
}

export default Home;
