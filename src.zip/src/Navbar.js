import "./Navbar.css";

import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import {  Link } from "react-router-dom";



const Navbar = () => {
  return (
    
<div className="menu">
<h1 className="menuTitle">Welcome Admin</h1>
<div className="menuList">
    <div className="menuItem">
      <div className='menuimage'><img src='https://creazilla-store.fra1.digitaloceanspaces.com/icons/3233393/file-upload-icon-md.png' alt='working' /></div>
      <div className='menuInfo'> 
      <h5>Add New Book</h5>
            <Link to='/addBook' className="btn btn-primary">Add New Book</Link>
    </div></div>
    </div>
{/* ------------------------------------------------------- */}
<div className="menuList">
    <div className="menuItem">
      <div className='menuimage'><img src='https://th.bing.com/th/id/OIP.ESYCeCQcbOqIf_Hp4TwxdgHaHa?pid=ImgDet&w=474&h=474&rs=1' /></div>
      <div className='menuInfo'> 
      <h5>Manage Books</h5>
            <Link to='/manageBook' className="btn btn-primary">Manage Books</Link>
    </div></div>
      </div>
      {/* ------------------------------------------------------- */}
<div className="menuList">
    <div className="menuItem">
      <div className='menuimage'><img src='https://thumbs.dreamstime.com/z/admin-sign-laptop-icon-stock-vector-166205404.jpg?w=450' /></div>
      <div className='menuInfo'> 
      <h5>Add New Admin</h5>
            <Link to='/addNewAdmin' className="btn btn-primary">Add new Admin</Link>
    </div></div>
      </div>
      </div>
  );
};

export default Navbar;
