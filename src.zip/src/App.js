import React from 'react'
import './App.css'
import Home from "./pages/Home"
import Login from "./Components/LoginAdmin/LoginAdmin"
import Showbook from './Components/ShowBook/Showbooks'
import BookList from './Components/ShowBook/BookList'
import About from './pages/About'
import Contact from './pages/Contact'
import logo from './assets/logo.png'
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Footer from "./Components/Footer/Footer";
import Navbar from './Navbar'
import AddNewAdmin from './Components/LoginAdmin/AddNewAdmin'
import AddBook from './Components/AddBook/AddBook'
import EditBook from './Components/EditBook/EditBook'


function App() {
  return (
    <div className="App">
    <Router>
        <div className="header">
          <nav className="nav">
            <Link to="/Navbar" className="nav-linkimg">
              <img src={logo}  alt="logo" />
              </Link>
          <Link to="/" className="nav-link">
            Home
          </Link>
          <Link to="/showbook" className="nav-link">
            Library {" "}
          </Link>
          <Link to="/About" className="nav-link">
            About {" "}
        </Link>
            <Link to="/Contact" className="nav-link">
            Contact {" "}
          </Link>
        <Link to="/loginAdmin" className="nav-link">
            Login {" "}
          </Link>
        </nav>
      </div>
      <div className="content">
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/showbook" element={<Showbook/>}/>
          <Route path="/About" element={<About/>}/>
          <Route path="/Contact" element={<Contact />} />
            <Route path="/loginAdmin" element={<Login />} />
            <Route path="/Navbar" element={<Navbar />} />
            <Route path="/addNewAdmin" element={<AddNewAdmin />} />
            <Route path="/addBook" element={<AddBook />} />
            <Route path="/manageBook" element={<BookList />} />
            <Route path="/editBook/:id" element={<EditBook />} />
            
    </Routes>            
      </div>
      <Footer />
    </Router>
  </div>
  );
}

export default App;