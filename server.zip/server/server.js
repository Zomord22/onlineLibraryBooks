// CREATE SERVER
const express = require("express")
const app = express()
const cors = require("cors")
app.use(cors())
app.use(express.json())

// CONNECT TO DB
const mongoose = require("mongoose")
mongoose.connect("mongodb+srv://36s2023:admin12@cluster.3oiruo6.mongodb.net/project?retryWrites=true&w=majority&appName=Cluster")
// Admin MODEL
const AdminModel = require('./models/Admin')

// Add New Admin
app.post("/addNewAdmin",async(req,res)=>{
  const{email,password}=req.body
  const newAdmin={
      email:email,
      password:password
  }
  try{
      const check=await AdminModel.findOne({email:email})
      if(check){
        res.json("exist")
      }
      else{
          res.json("notexist")
        await newAdmin.save();
        res.send({ msg: "Admin successfully added." });
      }
  }
  catch(e){
      res.json("fail")
  }
})


//Login Admin
app.post('/loginAdmin', async (req, res) => {
  const { email, password } = req.body;
  try {
    const Admin = await AdminModel.find({email});

    if (!Admin) {
      return res.status(404).send({ message: 'Admin not found' });
    }

    if (!Admin.password || password !== Admin.password) {
      return res.status(401).send({ message: 'Invalid password' });
    }

    // Login successful
    return res.status(200).send({ message: 'Login successful' });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ message: 'Server error' });
  }
});


//The second collection is Book 
const BookModel = require('./models/Book')
//express POST route for adding new student
app.post("/addBook", async (req, res) => {
  const name = req.body.name;
  const author = req.body.author;
  const publishYear = req.body.publishYear;
  const type = req.body.type;
  const image = req.body.image;

  try {
    const NewBook = new BookModel({
      name: name,
      author: author,
      publishYear: publishYear,
      type: type,
      image: image,
    });
    await NewBook.save();
    res.send({ msg: "Record successfully added." });
  } catch (err) {
    res.send({ msg: err });
  }
});

  
//express GET route for retrieving records from the database
app.get("/manage", async (req, res) => {
  try {
    const result = await BookModel.find({});
    const countBooks = await BookModel.countDocuments({});
    res.send({ result, count: countBooks });
  } catch (err) {
    res.send({ msg: "Error" });
  }
});


// Get all books
app.get('/ListBooks', async (req, res) => {
  try {
    const books = await BookModel.find();
    res.json(books);
  } catch (error) {
    console.error('Error retrieving books:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});
//find Book
app.get("/getBook/:id", async (req, res) => {
  const name = req.params.name;
  console.log(name);
  try {
    const result = await BookModel.findOne({ name: name });
    //if Book is not found
    if (!result) {
      return res.status(404).send({ msg: "Book not found" });
    }
    const countBook = await BookModel.countDocuments({});
    console.log(result);
    res.send({ result, count: countBook });
  } catch (err) {
    res.send({ msg: "Error" });
  }
});
// Delete a book
app.delete('/delete/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await BookModel.findByIdAndDelete(id);
    res.json({ message: 'Book deleted successfully' });
  } catch (error) {
    console.error('Error deleting book:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});





app.put("/editBook/:id", async (req, res) => {
  console.log(req);
  const name = req.body.name;
  const author = req.body.author;
  const publishYear = req.body.publishYear;
  const type = req.body.type;
  const image = req.body.image;

  try {
    const { id }  = req.params;
    const UpdateBook = await BookModel.findByIdAndUpdate(id, {
      name: name,
      author: author,
      publishYear: publishYear,
      type: type,
      image: image
    }, { new: true });
    console.log(UpdateBook);
    //if student is not found
    if (!UpdateBook) {
      return res.status(404).send({ msg: "Book not found" });
    }

    UpdateBook.save();
    res.send({ msg: "Record Updated" });
  } catch (err) {
    console.error(err);
    res.status(500).send({ msg: "Error updating record" });
  }
});


app.listen(3001, ()=>{
    console.log("Server Works")
})