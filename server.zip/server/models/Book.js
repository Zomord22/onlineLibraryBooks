const { Schema, model, default: mongoose } = require('mongoose');
const nodemon = require('nodemon');
const bookSchema = new Schema({
name:{
    type: String,
},
author:{
    type: String,
},
publishYear:{
    type: Number,
},
type:{
    type: String,
},
image:{
    type: String,
},
});


const BookModel = model("book", bookSchema)
module.exports = BookModel;



