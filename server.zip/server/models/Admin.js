const {Schema, model} = require("mongoose");

const AdminSchema=new Schema({
    email:{
        type:String,
        required:true
    },
    password:{
        type:Number,
        required:true
    }
})

const AdminModel = model("admin", AdminSchema)
module.exports = AdminModel